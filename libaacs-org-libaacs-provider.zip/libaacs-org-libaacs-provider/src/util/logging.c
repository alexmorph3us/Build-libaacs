/*
 * This file is part of libaacs
 * Copyright (C) 2009-2010  Obliter0n
 * Copyright (C) 2013       VideoLAN
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see
 * <http://www.gnu.org/licenses/>.
 */

#if HAVE_CONFIG_H
#include "config.h"
#endif

#include "logging.h"

#include "file/file.h"

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#ifdef __ANDROID__
#include <android/log.h>
#endif

uint32_t debug_mask = (uint32_t)-1; /* set all bits to make sure bd_debug() is called for initialization */

/*
 * On Android stderr is discarded unless the process was started from a
 * shell, so the default destination is logcat instead. A log file named by
 * AACS_DEBUG_FILE is still written to directly: only the default is
 * redirected.
 */
static void _log_write(FILE *logfile, uint32_t mask, const char *msg)
{
#ifdef __ANDROID__
    if (logfile == stderr) {
        size_t len = strlen(msg);
        /* logcat delimits entries itself, a trailing newline would add an
         * empty line to every message */
        if (len > 0 && msg[len - 1] == '\n') {
            len--;
        }
        __android_log_print((mask & DBG_CRIT) ? ANDROID_LOG_ERROR : ANDROID_LOG_DEBUG,
                            "libaacs", "%.*s", (int)len, msg);
        return;
    }
#else
    (void)mask;
#endif

    fprintf(logfile, "%s", msg);
}

void bd_debug(const char *file, int line, uint32_t mask, const char *format, ...)
{
    static int   debug_init = 0;
    static FILE *logfile    = NULL;

    // Only call getenv() once.
    if (!debug_init) {
        debug_init = 1;
        logfile = stderr;

        char *env = NULL;
        if (debug_mask == (uint32_t)-1) {
            /* might be set by application with bd_set_debug_mask() */
            debug_mask = DBG_CRIT;
        }
        if ((env = getenv("AACS_DEBUG_MASK")))
            debug_mask = strtol(env, NULL, 0);
        else if ((env = getenv("BD_DEBUG_MASK")))
            debug_mask = strtol(env, NULL, 0);

        // Send DEBUG to file?
        if ((env = getenv("AACS_DEBUG_FILE"))) {
            FILE *fp = fopen(env, "wb");
            if (fp) {
                logfile = fp;
                setvbuf(logfile, NULL, _IONBF, 0);
            } else {
                char err[512];
                snprintf(err, sizeof(err), "%s:%d: Error opening log file %s\n",
                         __FILE__, __LINE__, env);
                _log_write(logfile, DBG_CRIT, err);
            }
        }
    }

    if (mask & debug_mask) {
        const char *f = strrchr(file, DIR_SEP_CHAR);
        char buffer[4096], *pt = buffer;
        va_list args;

        pt += sprintf(buffer, "%s:%d: ", f ? f + 1 : file, line);

        va_start(args, format);
        vsnprintf(pt, sizeof(buffer) - (size_t)(intptr_t)(pt - buffer) - 1, format, args);
        va_end(args);

        _log_write(logfile, mask, buffer);
    }
}
